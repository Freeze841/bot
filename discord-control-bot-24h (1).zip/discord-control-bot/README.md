# Discord Control — bot Among Us + tableau de bord optionnel

Le bot contient la commande slash `/amongus`. Elle envoie un panneau avec deux boutons :
- **MUTER TOUT LE MONDE** : mute serveur tous les membres humains du salon vocal dans lequel se trouve la personne qui clique.
- **DÉMUTER TOUT LE MONDE** : retire le mute serveur aux membres humains de ce salon.

Les deux actions sont réservées aux personnes ayant la permission Discord **Muter les membres** ou **Administrateur**. Le bot a lui aussi besoin de la permission **Muter les membres**. Les bots ne sont pas mutés par défaut. Le bot ne modifie pas le micro physique des joueurs.

## Démarrer le bot seul (recommandé pour l'hébergement)

Le bot peut fonctionner avec uniquement `DISCORD_BOT_TOKEN`. Ajoute cette variable comme secret dans le fournisseur d'hébergement ou dans l'environnement du service. Pas besoin du Client Secret OAuth2 ni d'un tableau de bord pour la commande `/amongus`.

Pour lancer en local si Node.js 20+ est installé :

```bash
npm install
DISCORD_BOT_TOKEN="ton_nouveau_token" npm start
```

Sous Windows PowerShell, configure temporairement la variable ainsi :

```powershell
$env:DISCORD_BOT_TOKEN = "ton_nouveau_token"
npm start
```

Ne partage jamais le token. S'il a été affiché ou envoyé à quelqu'un, régénère-le avant de l'utiliser.

## Ajouter le bot au serveur

Dans Discord Developer Portal :
1. Ouvre l'application du bot, puis **OAuth2 → URL Generator**.
2. Sélectionne les scopes `bot` et `applications.commands`.
3. Donne au bot au minimum la permission **Mute Members / Muter les membres**.
4. Ouvre le lien généré et ajoute le bot à ton serveur.
5. Dans **Bot**, active l'intent privilégié **Server Members Intent** uniquement si tu actives le tableau de bord ou le message de bienvenue. En mode bot Among Us seul, il n'est pas nécessaire. Le bot active l'intent de voix requis.

Au démarrage, le bot crée ou met à jour `/amongus` dans chacun des serveurs où il se trouve. Rejoins un vocal, puis tape `/amongus` dans un salon textuel.

## Hébergement 24 h/24 sous Ubuntu

Pour installer le bot sur une VM Ubuntu déjà créée, consulter [`deploy/README-HEBERGEMENT.md`](deploy/README-HEBERGEMENT.md) et lancer `sudo bash deploy/install-ubuntu.sh`. Le service systemd s'active au démarrage et redémarre le bot en cas de crash.

Le logiciel seul ne crée pas un compte cloud ni une VM. Le titulaire doit effectuer les étapes d'inscription / validation du fournisseur. Sur Oracle Cloud Free Tier, seuls les composants explicitement marqués **Always Free** sont gratuits au-delà de l'essai ; la capacité gratuite peut être momentanément indisponible. Vérifie les ressources et estimations de coût dans la console avant création.

## Tableau de bord web (facultatif)

Le tableau de bord d'origine reste inclus. Il s'active uniquement si les variables suivantes sont toutes configurées : `DISCORD_CLIENT_ID`, `DISCORD_CLIENT_SECRET` et `SESSION_SECRET`, en plus du token du bot. Pour l'héberger publiquement, il faut configurer OAuth2, HTTPS et l'URL de redirection exacte. Sans ces trois variables, seule une page de santé textuelle est exposée, et les commandes du bot continuent de fonctionner.

Exemple de configuration complète : voir `.env.example`. N'ajoute jamais de vrais secrets à un ZIP, à un dépôt GitHub, à des captures d'écran ou à un message.

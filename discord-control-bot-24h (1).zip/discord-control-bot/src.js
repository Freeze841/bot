require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { Client, GatewayIntentBits, PermissionFlagsBits, ChannelType, SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');

// The bot can run by itself with only DISCORD_BOT_TOKEN (ideal for 24/7 hosting).
// The web dashboard is enabled only when all three OAuth/session settings are supplied.
const required = ['DISCORD_BOT_TOKEN'];
for (const key of required) {
  if (!process.env[key] || process.env[key].startsWith('put_your_') || process.env[key].startsWith('your_') || process.env[key].startsWith('replace_')) {
    console.error(`Missing configuration: ${key}. Add it as a hosting secret/environment variable.`);
    process.exit(1);
  }
}
const dashboardKeys = ['DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET', 'SESSION_SECRET'];
const dashboardEnabled = dashboardKeys.every(key => Boolean(process.env[key] && !/^(put_your_|your_|replace_)/i.test(process.env[key])));
if (!dashboardEnabled && dashboardKeys.some(key => Boolean(process.env[key]))) {
  console.warn('Dashboard disabled: set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET and SESSION_SECRET together to enable it.');
}

const app = express();
const port = Number(process.env.PORT || 3000);
const redirectUri = process.env.DISCORD_REDIRECT_URI || `http://localhost:${port}/auth/callback`;
const storePath = path.join(__dirname, 'store.json');
let store = {};
try { store = JSON.parse(fs.readFileSync(storePath, 'utf8')); } catch {}
function saveStore() { fs.writeFileSync(storePath, JSON.stringify(store, null, 2)); }

// Server Members is a privileged intent and is only needed by optional dashboard/welcome features.
// Keeping it off in bot-only mode avoids requiring an extra Developer Portal setting.
const clientIntents = [GatewayIntentBits.Guilds, GatewayIntentBits.GuildVoiceStates];
if (dashboardEnabled) clientIntents.push(GatewayIntentBits.GuildMembers);
const client = new Client({ intents: clientIntents });

const amongUsCommand = new SlashCommandBuilder()
  .setName('amongus')
  .setDescription('Affiche les boutons pour muter/démuter le salon vocal Among Us')
  .setDefaultMemberPermissions(PermissionFlagsBits.MuteMembers);

async function registerAmongUsCommand(guild) {
  try {
    const existing = await guild.commands.fetch();
    const command = existing.find(cmd => cmd.name === 'amongus');
    if (command) await command.edit(amongUsCommand.toJSON());
    else await guild.commands.create(amongUsCommand.toJSON());
    console.log(`Commande /amongus prête sur ${guild.name}`);
  } catch (error) {
    console.error(`Impossible d'enregistrer /amongus sur ${guild.name}:`, error.message);
  }
}

client.once('ready', async () => {
  console.log(`Bot connected as ${client.user.tag}`);
  for (const guild of client.guilds.cache.values()) await registerAmongUsCommand(guild);
});
client.on('guildCreate', registerAmongUsCommand);

function amongUsPanel() {
  const embed = new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('🎮 Mode Among Us')
    .setDescription(`Rejoins le salon vocal avec les joueurs, puis utilise un bouton ci-dessous.\n\n🔇 **MUTER** : coupe le micro serveur de tous les membres humains présents dans ton salon vocal.\n🎙️ **DÉMUTER** : réactive leur micro serveur.`)
    .setFooter({ text: 'Utilisation réservée aux membres ayant la permission Mute Members.' });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('amongus:mute').setLabel('MUTER TOUT LE MONDE').setEmoji('🔇').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('amongus:unmute').setLabel('DÉMUTER TOUT LE MONDE').setEmoji('🎙️').setStyle(ButtonStyle.Success)
  );
  return { embeds: [embed], components: [row] };
}

client.on('interactionCreate', async interaction => {
  if (interaction.isChatInputCommand() && interaction.commandName === 'amongus') {
    if (!interaction.inGuild()) return interaction.reply({ content: 'Cette commande doit être utilisée dans un serveur.', ephemeral: true });
    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
    if (!member) return interaction.reply({ content: 'Impossible de vérifier tes permissions Discord.', ephemeral: true });
    if (!member.permissions.has(PermissionFlagsBits.MuteMembers) && !member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: 'Il te faut la permission **Mute Members / Muter les membres** pour utiliser ce panneau.', ephemeral: true });
    }
    const me = await interaction.guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.MuteMembers)) {
      return interaction.reply({ content: 'Le bot doit avoir la permission **Muter les membres** dans les paramètres du serveur.', ephemeral: true });
    }
    return interaction.reply({ ...amongUsPanel(), allowedMentions: { parse: [] } });
  }

  if (!interaction.isButton() || !interaction.customId.startsWith('amongus:')) return;
  if (!interaction.inGuild()) return interaction.reply({ content: 'Ce bouton fonctionne uniquement dans un serveur.', ephemeral: true });
  const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
  if (!member) return interaction.reply({ content: 'Impossible de vérifier tes permissions Discord.', ephemeral: true });
  if (!member.permissions.has(PermissionFlagsBits.MuteMembers) && !member.permissions.has(PermissionFlagsBits.Administrator)) {
    return interaction.reply({ content: 'Tu n’as pas la permission **Muter les membres** pour utiliser ces boutons.', ephemeral: true });
  }
  const botMember = await interaction.guild.members.fetchMe();
  if (!botMember.permissions.has(PermissionFlagsBits.MuteMembers)) {
    return interaction.reply({ content: 'Le bot n’a pas la permission **Muter les membres**.', ephemeral: true });
  }
  const voiceChannel = member.voice?.channel;
  if (!voiceChannel) {
    return interaction.reply({ content: 'Rejoins d’abord le salon vocal que tu veux gérer, puis clique à nouveau sur le bouton.', ephemeral: true });
  }

  await interaction.deferReply({ ephemeral: true });
  const shouldMute = interaction.customId === 'amongus:mute';
  const players = voiceChannel.members.filter(m => !m.user.bot);
  if (players.size === 0) return interaction.editReply('Aucun joueur humain n’est présent dans ce salon vocal.');
  const results = await Promise.allSettled(players.map(m => m.voice.setMute(shouldMute, `Mode Among Us déclenché par ${interaction.user.tag}`)));
  const success = results.filter(r => r.status === 'fulfilled').length;
  const failed = results.length - success;
  const verb = shouldMute ? 'muté(s)' : 'démuté(s)';
  let message = `🎮 ${success} joueur(s) ${verb} dans **${voiceChannel.name}**.`;
  if (failed) message += `\n⚠️ ${failed} action(s) ont échoué. Vérifie la permission du bot et la hiérarchie des rôles.`;
  return interaction.editReply(message);
});
client.on('guildMemberAdd', async member => {
  const settings = store[member.guild.id] || {};
  if (!settings.welcomeChannelId || !settings.welcomeMessage) return;
  const channel = member.guild.channels.cache.get(settings.welcomeChannelId);
  if (channel?.isTextBased()) {
    const message = settings.welcomeMessage.replaceAll('{user}', `<@${member.id}>`).replaceAll('{server}', member.guild.name);
    channel.send({ content: message }).catch(err => console.error('Welcome message failed:', err.message));
  }
});

if (dashboardEnabled) {
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(session({
  name: 'discord_dashboard_session',
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));
app.use('/api', rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

async function discordApi(route, options = {}, token = null) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  else headers.Authorization = `Bot ${process.env.DISCORD_BOT_TOKEN}`;
  const response = await fetch(`https://discord.com/api/v10${route}`, { ...options, headers });
  const body = response.status === 204 ? null : await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.message || `Discord API error (${response.status})`);
  return body;
}

function requireLogin(req, res, next) {
  if (!req.session.user || !req.session.accessToken) return res.status(401).json({ error: 'Connecte-toi avec Discord.' });
  next();
}
async function canManageGuild(req, guildId) {
  const guilds = await discordApi('/users/@me/guilds', {}, req.session.accessToken);
  const guild = guilds.find(g => g.id === guildId);
  if (!guild) return false;
  const p = BigInt(guild.permissions || '0');
  return (p & PermissionFlagsBits.Administrator) === PermissionFlagsBits.Administrator ||
    (p & PermissionFlagsBits.ManageGuild) === PermissionFlagsBits.ManageGuild;
}
async function guildContext(req, res, next) {
  try {
    const guildId = req.params.guildId;
    if (!/^\d{17,20}$/.test(guildId)) return res.status(400).json({ error: 'Identifiant de serveur invalide.' });
    if (!(await canManageGuild(req, guildId))) return res.status(403).json({ error: 'Tu dois avoir la permission Gérer le serveur sur ce serveur.' });
    const guild = await client.guilds.fetch(guildId).catch(() => null);
    if (!guild) return res.status(404).json({ error: 'Le bot ne se trouve pas sur ce serveur.' });
    const me = await guild.members.fetchMe().catch(() => null);
    if (!me) return res.status(403).json({ error: 'Impossible de vérifier les permissions du bot.' });
    req.guild = guild;
    next();
  } catch (e) { res.status(500).json({ error: e.message }); }
}

app.get('/auth/login', (req, res) => {
  const params = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, redirect_uri: redirectUri, response_type: 'code', scope: 'identify guilds' });
  res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});
app.get('/auth/callback', async (req, res) => {
  try {
    if (!req.query.code) return res.redirect('/?error=oauth');
    const form = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, client_secret: process.env.DISCORD_CLIENT_SECRET, grant_type: 'authorization_code', code: String(req.query.code), redirect_uri: redirectUri });
    const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: form });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok) throw new Error(tokenData.error_description || 'Connexion Discord impossible');
    const user = await discordApi('/users/@me', {}, tokenData.access_token);
    req.session.user = { id: user.id, username: user.global_name || user.username, avatar: user.avatar };
    req.session.accessToken = tokenData.access_token;
    res.redirect('/');
  } catch (e) { console.error('OAuth error:', e.message); res.redirect('/?error=oauth'); }
});
app.post('/auth/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));
app.get('/api/guilds', requireLogin, async (req, res) => {
  try {
    const guilds = await discordApi('/users/@me/guilds', {}, req.session.accessToken);
    const manageable = guilds.filter(g => {
      const p = BigInt(g.permissions || '0');
      return (p & PermissionFlagsBits.Administrator) === PermissionFlagsBits.Administrator || (p & PermissionFlagsBits.ManageGuild) === PermissionFlagsBits.ManageGuild;
    });
    res.json(manageable.map(g => ({ id: g.id, name: g.name, icon: g.icon, botPresent: client.guilds.cache.has(g.id) })));
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/guild/:guildId/overview', requireLogin, guildContext, async (req, res) => {
  try {
    const g = req.guild;
    const channels = await g.channels.fetch();
    const roles = await g.roles.fetch();
    res.json({ id: g.id, name: g.name, memberCount: g.memberCount, channels: channels.filter(c => c).map(c => ({ id: c.id, name: c.name, type: c.type })).sort((a,b) => a.name.localeCompare(b.name)), roles: roles.filter(r => r.id !== g.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor, position: r.position })).sort((a,b) => b.position-a.position), settings: store[g.id] || {} });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/guild/:guildId/members', requireLogin, guildContext, async (req, res) => {
  try {
    const members = await req.guild.members.fetch({ limit: 100 });
    res.json(members.map(m => ({ id: m.id, username: m.user.username, displayName: m.displayName, bot: m.user.bot, timeout: m.communicationDisabledUntil?.toISOString() || null })).sort((a,b) => a.displayName.localeCompare(b.displayName)));
  } catch (e) { res.status(500).json({ error: `Impossible de charger les membres. Vérifie l'intent Server Members Intent dans le Developer Portal. ${e.message}` }); }
});
app.post('/api/guild/:guildId/moderate', requireLogin, guildContext, async (req, res) => {
  try {
    const { action, userId, reason = 'Action depuis le tableau de bord' } = req.body || {};
    if (!/^\d{17,20}$/.test(userId || '')) return res.status(400).json({ error: 'Identifiant de membre invalide.' });
    const member = await req.guild.members.fetch(userId).catch(() => null);
    if (!member) return res.status(404).json({ error: 'Membre introuvable ou inconnu du bot.' });
    const botMember = await req.guild.members.fetchMe();
    if (member.id === req.session.user.id || member.id === client.user.id || member.id === req.guild.ownerId) return res.status(400).json({ error: 'Cette action est interdite sur ce compte.' });
    if (action === 'timeout') {
      if (!botMember.permissions.has(PermissionFlagsBits.ModerateMembers)) return res.status(403).json({ error: 'Le bot doit avoir la permission Modérer les membres.' });
      await member.timeout(10 * 60 * 1000, reason);
    } else if (action === 'kick') {
      if (!botMember.permissions.has(PermissionFlagsBits.KickMembers)) return res.status(403).json({ error: 'Le bot doit avoir la permission Expulser des membres.' });
      await member.kick(reason);
    } else if (action === 'ban') {
      if (!botMember.permissions.has(PermissionFlagsBits.BanMembers)) return res.status(403).json({ error: 'Le bot doit avoir la permission Bannir des membres.' });
      await member.ban({ reason });
    } else return res.status(400).json({ error: 'Action inconnue.' });
    res.json({ ok: true, message: `Action « ${action} » effectuée sur ${member.user.username}.` });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/guild/:guildId/role', requireLogin, guildContext, async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim();
    if (!name || name.length > 100) return res.status(400).json({ error: 'Le nom du rôle doit contenir de 1 à 100 caractères.' });
    const me = await req.guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.ManageRoles)) return res.status(403).json({ error: 'Le bot doit avoir la permission Gérer les rôles.' });
    const role = await req.guild.roles.create({ name, reason: 'Créé depuis le tableau de bord' });
    res.json({ ok: true, role: { id: role.id, name: role.name } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/guild/:guildId/channel', requireLogin, guildContext, async (req, res) => {
  try {
    const name = String(req.body?.name || '').trim().toLowerCase().replace(/\s+/g, '-');
    if (!/^[a-z0-9_-]{1,100}$/.test(name)) return res.status(400).json({ error: 'Utilise 1 à 100 caractères : lettres sans accent, chiffres, tirets ou _.' });
    const me = await req.guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.ManageChannels)) return res.status(403).json({ error: 'Le bot doit avoir la permission Gérer les salons.' });
    const channel = await req.guild.channels.create({ name, type: ChannelType.GuildText, reason: 'Créé depuis le tableau de bord' });
    res.json({ ok: true, channel: { id: channel.id, name: channel.name } });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post('/api/guild/:guildId/settings', requireLogin, guildContext, async (req, res) => {
  try {
    const welcomeMessage = String(req.body?.welcomeMessage || '').slice(0, 1000);
    const welcomeChannelId = String(req.body?.welcomeChannelId || '');
    if (welcomeChannelId && !/^\d{17,20}$/.test(welcomeChannelId)) return res.status(400).json({ error: 'Identifiant de salon invalide.' });
    if (welcomeChannelId && !req.guild.channels.cache.has(welcomeChannelId)) return res.status(400).json({ error: 'Ce salon ne se trouve pas sur le serveur.' });
    store[req.guild.id] = { ...(store[req.guild.id] || {}), welcomeMessage, welcomeChannelId };
    saveStore();
    res.json({ ok: true, message: 'Paramètres sauvegardés.' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.get('/api/health', (req, res) => res.json({ web: 'ok', bot: client.isReady() }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
} else {
  app.use(helmet());
  app.get('/api/health', (req, res) => res.json({ web: 'ok', bot: client.isReady(), dashboard: false }));
  app.get('*', (req, res) => res.type('text/plain').send('Discord Among Us bot is running. The web dashboard is disabled.'));
}

app.listen(port, '0.0.0.0', () => console.log(dashboardEnabled ? `Dashboard available on port ${port}` : `Discord bot health endpoint available on port ${port}; dashboard disabled`));
client.login(process.env.DISCORD_BOT_TOKEN).catch(e => { console.error('Bot login failed:', e.message); process.exit(1); });

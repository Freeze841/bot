#!/usr/bin/env bash
set -Eeuo pipefail

# Installs this project as a systemd service on Ubuntu 22.04/24.04.
# Run from the extracted project directory: sudo bash deploy/install-ubuntu.sh

if [[ "${EUID}" -ne 0 ]]; then
  echo "Lance ce script avec sudo : sudo bash deploy/install-ubuntu.sh" >&2
  exit 1
fi
if [[ ! -f "package.json" || ! -f "src.js" ]]; then
  echo "Erreur : lance ce script depuis le dossier du projet (là où se trouvent package.json et src.js)." >&2
  exit 1
fi

APP_NAME="discord-control-bot"
APP_DIR="/opt/${APP_NAME}"
SERVICE_USER="discordbot"
ENV_FILE="/etc/${APP_NAME}.env"

read -r -s -p "Colle le NOUVEAU token du bot Discord (il ne sera pas affiché) : " DISCORD_BOT_TOKEN
echo
if [[ -z "${DISCORD_BOT_TOKEN}" ]]; then
  echo "Le token ne peut pas être vide." >&2
  exit 1
fi
if [[ "${DISCORD_BOT_TOKEN}" == *$'\n'* || "${DISCORD_BOT_TOKEN}" == *$'\r'* ]]; then
  echo "Le token contient un retour à la ligne inattendu." >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg
if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 20 ? 0 : 1)'; then
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
  chmod 0644 /etc/apt/keyrings/nodesource.gpg
  NODE_MAJOR=22
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" > /etc/apt/sources.list.d/nodesource.list
  apt-get update
  apt-get install -y nodejs
fi

if ! id -u "${SERVICE_USER}" >/dev/null 2>&1; then
  useradd --system --home-dir "${APP_DIR}" --shell /usr/sbin/nologin "${SERVICE_USER}"
fi
install -d -o "${SERVICE_USER}" -g "${SERVICE_USER}" -m 0750 "${APP_DIR}"
# Copy only project files; never copy local env files, installed packages, or saved local data.
tar --exclude='./.env' --exclude='./.env.*' --exclude='./node_modules' --exclude='./store.json' --exclude='./.git' -cf - . | tar -xf - -C "${APP_DIR}"

chown -R "${SERVICE_USER}:${SERVICE_USER}" "${APP_DIR}"
runuser -u "${SERVICE_USER}" -- npm --prefix "${APP_DIR}" install --omit=dev --no-audit --no-fund

umask 077
printf 'DISCORD_BOT_TOKEN=%s\nNODE_ENV=production\nPORT=3000\n' "${DISCORD_BOT_TOKEN}" > "${ENV_FILE}"
chown root:"${SERVICE_USER}" "${ENV_FILE}"
chmod 0640 "${ENV_FILE}"
unset DISCORD_BOT_TOKEN

cat > "/etc/systemd/system/${APP_NAME}.service" <<UNIT
[Unit]
Description=Discord Among Us Bot
Wants=network-online.target
After=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
Group=${SERVICE_USER}
WorkingDirectory=${APP_DIR}
EnvironmentFile=${ENV_FILE}
ExecStart=/usr/bin/node ${APP_DIR}/src.js
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${APP_DIR}

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now "${APP_NAME}.service"
echo
echo "Installation terminée. Le bot démarre automatiquement au redémarrage du serveur."
echo "État : systemctl status ${APP_NAME}"
echo "Logs : journalctl -u ${APP_NAME} -f"
echo "Santé locale : curl http://127.0.0.1:3000/api/health"
echo "Le tableau de bord web reste désactivé tant que les variables OAuth2 ne sont pas définies."

# Hébergement 24 h/24 sur un serveur Ubuntu

Ce dossier permet d'installer le bot avec un service systemd qui se relance après un crash et redémarre après le redémarrage de la VM.

## Prérequis
- Une VM Ubuntu 22.04 ou 24.04 déjà créée chez un fournisseur cloud.
- Un accès SSH avec sudo.
- Le bot invité dans le serveur Discord avec la permission « Muter les membres ».
- Le nouveau token du bot, saisi uniquement au prompt du script d'installation.

## Installation
1. Transférer et extraire le ZIP sur la VM.
2. Dans le terminal SSH, aller dans le dossier du projet.
3. Exécuter `sudo bash deploy/install-ubuntu.sh`.
4. Coller le nouveau token quand le script le demande. Il ne sera pas affiché à l'écran.

Le script installe Node.js si nécessaire, installe les dépendances, range le secret dans `/etc/discord-control-bot.env` avec des permissions restreintes et active le service systemd.

## Vérifier / diagnostiquer
- `sudo systemctl status discord-control-bot`
- `sudo journalctl -u discord-control-bot -n 100 --no-pager`
- `sudo systemctl restart discord-control-bot`

## Notes de sécurité
- N'ajoute jamais `.env` ou un token au ZIP ni à un dépôt GitHub.
- En cas d'exposition du token, régénère-le dans Discord Developer Portal avant l'installation.
- Les commandes slash `/amongus` sont enregistrées automatiquement au démarrage dans chaque serveur où le bot est présent.
- Le compte cloud et la création de la VM doivent être réalisés et validés par le titulaire du compte. Ne désactive pas les protections de facturation et n'active pas une offre payante pour contourner une limite gratuite.
